package com.example.myewaste.utils;

public enum Mode {
    MODE_SUPER_ADMIN,
    MODE_TELLER,
    MODE_NASABAH
}
